//
//  Model.swift
//  mpoo_06
//
//  Created by Germán Santos Jaimes on 18/09/24.
//

import Foundation

struct Alumno{
    var nombre:String
    var imagen:String
}
