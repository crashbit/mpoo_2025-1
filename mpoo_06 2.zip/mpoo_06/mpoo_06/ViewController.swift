//
//  ViewController.swift
//  mpoo_06
//
//  Created by Germán Santos Jaimes on 11/09/24.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
    
    var alumnos:[Alumno] = [
        Alumno(nombre: "Pedro", imagen: "uno"),
        Alumno(nombre: "Diana", imagen: "dos"),
        Alumno(nombre: "Luis", imagen: "tres")
    ]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return alumnos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath) as! CeldaTableViewCell
        
        //cell.textLabel?.text = alumno[indexPath.row]
        
        var nombre = alumnos[indexPath.row].nombre
        var imagen = alumnos[indexPath.row].imagen
        
        cell.nombre.text = nombre
        cell.imagen.image = UIImage(named: imagen)
        
        return cell
    }
}

