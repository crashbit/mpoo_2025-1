//
//  ViewController.swift
//  mpoo_02
//
//  Created by Germán Santos Jaimes on 26/08/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var letrero: UILabel!
    @IBOutlet weak var sliderillo: UISlider!
    var contador:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func clickme(_ sender: UIButton) {
        contador = contador + 1
        print(contador)
        letrero.text = String(contador)
    }
    
    @IBAction func resetea(_ sender: UIButton){
        contador = 0
        letrero.text = String(contador)
    }
    
    @IBAction func cambia(_ sender: UISlider){
        var valor = Int(sliderillo.value)
        letrero.text = String(valor)
    }
    
}

