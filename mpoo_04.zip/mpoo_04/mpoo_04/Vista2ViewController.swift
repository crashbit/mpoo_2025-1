//
//  Vista2ViewController.swift
//  mpoo_04
//
//  Created by Germán Santos Jaimes on 04/09/24.
//

import UIKit

class Vista2ViewController: UIViewController {

    @IBOutlet weak var etiqueta: UILabel!
    var recibe: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        etiqueta.text = recibe
        print(recibe)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
