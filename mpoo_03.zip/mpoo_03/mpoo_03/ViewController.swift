//
//  ViewController.swift
//  mpoo_03
//
//  Created by Germán Santos Jaimes on 02/09/24.
//

import UIKit

class ViewController: UIViewController {
    var nombre:String?
    var i = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        
        nombre = nil
        //print(nombre!)
        
        if let nombre2 = nombre{
            print(nombre2)
        }else{
            print("Valor nulo")
        }
        
        let nombre2 = nombre ?? "nobody"
        print(nombre2)
        
        optionalGuarding(cadena: nil)
    }

    func optionalGuarding(cadena:String?){
        guard let cadena = cadena else{
            print("Cadena NO trae algo")
            return
        }
        print(cadena)
    }

}

