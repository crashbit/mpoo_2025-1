//
//  ViewController.swift
//  PinchViewsIOS
//
//  Created by Germán Santos Jaimes on 17/10/24.
//

import UIKit

class ViewController: UIViewController {
    private let miVista: UIView = {
        let v = UIView()
        v.backgroundColor = UIColor.red
        return v
    }()
    
    private let size = 100
    
    override func viewDidLoad() {
        super.viewDidLoad()
        miVista.frame = CGRect(x: 0, y: 0, width: size, height: size)
        miVista.center = view.center
        
        view.addSubview(miVista)
        
        addGesture()
    }

    private func addGesture (){
        let pinchGesture = UIPinchGestureRecognizer(target: self, action: #selector(didPich(_:)))
                                                    
        miVista.addGestureRecognizer(pinchGesture)
    }
    
    @objc private func didPich(_ gesture: UIPinchGestureRecognizer){
        if gesture.state == .changed {
            let scale = gesture.scale
            miVista.frame = CGRect(x: 0,
                                   y: 0,
                                   width: size * Int(scale),
                                   height: size * Int(scale)
                                    )
            miVista.center = view.center
            
        }
    }
}

