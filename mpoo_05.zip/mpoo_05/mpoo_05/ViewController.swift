//
//  ViewController.swift
//  mpoo_05
//
//  Created by Germán Santos Jaimes on 09/09/24.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {

    var alumnos:[String] = ["loreta", "juan", "julia", "daniela", "luis", "chucho"]

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return alumnos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        cell.textLabel?.text = alumnos[indexPath.row]
        cell.imageView?.image = UIImage(contentsOfFile: "piolin")
        
        return cell
    }

    
}

