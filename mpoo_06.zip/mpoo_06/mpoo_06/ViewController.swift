//
//  ViewController.swift
//  mpoo_06
//
//  Created by Germán Santos Jaimes on 11/09/24.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
    
    var alumno:[String] = ["Luis", "Pedro", "Daniel"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return alumno.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath) as! CeldaTableViewCell
        
        //cell.textLabel?.text = alumno[indexPath.row]
        
        cell.nombre.text = alumno[indexPath.row]
        
        return cell
    }
}

